module.exports = {
    spec: [
        'exemplo/capturar.spec.js',
        'exemplo/abrirLoja.spec.js',
        'exemplo/comprarItem.spec.js',
        'exemplo/recuperarSave.spec.js',
        'exemplo/usarPocao.spec.js'
    ]
}