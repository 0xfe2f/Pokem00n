module.exports = podeUsarPocao = noPocoes => {
    return noPocoes > 0
}