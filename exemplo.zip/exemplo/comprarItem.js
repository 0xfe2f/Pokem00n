module.exports = podeComprarItem = (saldo, precoItem) => {
    return saldo >= precoItem
}