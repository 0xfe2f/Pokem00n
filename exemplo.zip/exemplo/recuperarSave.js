module.exports = recuperarSave = noSaves => {
    return noSaves > 0
}