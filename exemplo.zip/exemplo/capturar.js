module.exports = capturar = pokebolas => {
    return pokebolas > 0;
}