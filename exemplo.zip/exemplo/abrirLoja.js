module.exports = abrirLoja = dinheiro => {
    return dinheiro > 0;
}